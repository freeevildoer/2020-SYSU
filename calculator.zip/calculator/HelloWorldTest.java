package Hello;

import static org.junit.jupiter.api.Assertions.*;
import junit.framework.TestCase;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class HelloWorldTest extends TestCase {
	HelloWorld helloworld = new HelloWorld();
	@BeforeEach
	protected void setUp() throws Exception {
	}

	@Test
	void testGetStr() {
		helloworld.Hello();
		assertEquals("Hello world!",helloworld.getStr());
	}

}

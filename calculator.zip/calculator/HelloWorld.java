package Cac;
import java.util.*;
public class HelloWorld {
	String str;
	public void Hello(){
		str = "Hello world";
	}
	public String getStr() {
		return str;
	}
}	
	

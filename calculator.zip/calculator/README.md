# README

ant编译hellworld的代码放在了“使用ant实现HelloWorld的编译运行”文档中，包含了build.xml的代码和helloworld的代码。

junit的测试代码和hellworld的代码分别是HelloWorldTest.java和HelloWorld.java，修改包名后直接在eclipse上运行即可。

sonar-project.properties文件可以在配置了sonarQube的环境下直接使用，关于java小程序的分析TA已经检查过了。